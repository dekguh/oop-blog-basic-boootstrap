<?php
/*
CMS Blog basic 1.0 by I Kadek Teguh Mahesa
PHP Version 7.0 OOP
Database Mysql PDO
Template Blog Bootstrap 4
Template Admin Panel SB-ADMIN (https://startbootstrap.com/template-overviews/sb-admin/)
Maintance Page (https://bootsnipp.com/snippets/m0Vyl)

Feature:
  - wysiwyg html (summernote)
  - Category
  - Navigation Editor
  - Google Recaptcha
  - SEO Meta
  - Make Post
  - Make Page
  - Maintance

Before you use this CMS you must edit on method webConfig in class parent blog in line 119
*/
session_start();
ob_start();
date_default_timezone_set("Asia/Bangkok");

class blog{
  public $conn;
  public $tanggal;
  public $ipaddress;
  public $msgErr;
  public $totalData;
  public $urlQuery;
  // users
  public $name;
  public $users;
  public $email;
  public $pass;
  public $newPass;
  public $oldPass;
  public $typeuser;
  public $userid;
  public $status_user;
  //// web config
  public $statusmt;
  public $recaptchasecret;
  public $recaptchasite;
  public $titleweb;
  public $titlehead;
  public $metaauthor;
  public $metadesc;
  public $metakeyword;
  public $alexarank;
  public $metabing;
  public $googlewebmaster;
  public $googleanalytics;
  // article
  public $img;
  public $imgErr;
  public $imgTemp;
  public $imgID;
  public $imgName;
  public $imgSize;
  public $imgType;
  public $postTitle;
  public $postID;
  public $postContent;
  public $author;
  public $postStatus;
  // page
  public $pageID;
  public $pageTitle;
  public $pageContent;
  public $pageURL;
  public $pageStatus;
  // category
  public $category;
  public $catStatus;
  public $catID;
  // Template
  public $templateID;
  public $templateName;
  public $templateContent;
  // pagination
  public $hal;
  public $showPage;
  public $limitOffset;
  public $start;
  public $end;
  public $totalHal;
  public $selisih;
  // comment
  public $commentID;
  public $commentContent;

  public function __construct(){
    try{
      $this->conn = new PDO("mysql:host=localhost;dbname=blogger;","root","123456789");
    }catch(PDOException $e){
      die("Failed Konek");
    }
  }

  public function numRand($num){
    $karakter = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
    $data_rand = "";
    for($i=1;$i<=$num;$i++){
      $num_rand = rand(0,strlen($karakter)-1);
      $data_rand .= $karakter[$num_rand];
    }
    return $data_rand;
  }

  public function infowebConfig(){
    $infowebConfig = $this->conn->prepare("SELECT * FROM webconfig WHERE 1");
    $infowebConfig->execute();
    return $infowebConfig->fetch();
  }

  public function webConfig(){
    $data = [];
    $webConfig = $this->infowebConfig();

    if(!empty($webConfig["statusmt"])){
      $data["statusmt"] = $webConfig["statusmt"];
    }else{
      $data["statusmt"] = 2; // 1 = yes, 2 = no
    }

    if(!empty($webConfig["recaptchasecret"])){
      $data["recaptchasecret"] = $webConfig["recaptchasecret"];
    }else{
      $data["recaptchasecret"] = "edit Here";
    }

    if(!empty($webConfig["recaptchasite"])){
      $data["recaptchasite"] = $webConfig["recaptchasite"];
    }else{
      $data["recaptchasite"] = "Edit Here";
    }

    if(!empty($webConfig["titleweb"])){
      $data["titleweb"] = $webConfig["titleweb"];
    }else{
      $data["titleweb"] = "Dekguh Blog";
    }

    if(!empty($webConfig["titlehead"])){
      $data["titlehead"] = $webConfig["titlehead"];
    }else{
      $data["titlehead"] = "Dekguh Blog";
    }

    if(!empty($webConfig["metaauthor"])){
      $data["metaauthor"] = $webConfig["metaauthor"];
    }else{
      $data["metaauthor"] = "Dekguh";
    }

    if(!empty($webConfig["metadesc"])){
      $data["metadesc"] = $webConfig["metadesc"];
    }else{
      $data["metadesc"] = "Blog buatan teguh";
    }

    if(!empty($webConfig["metakeyword"])){
      $data["metakeyword"] = $webConfig["metakeyword"];
    }else{
      $data["metakeyword"] = "SEO, Tutorial";
    }

    if(!empty($webConfig["alexarank"])){
      $data["alexarank"] = $webConfig["alexarank"];
    }else{
      $data["alexarank"] = "";
    }

    if(!empty($webConfig["metabing"])){
      $data["metabing"] = $webConfig["metabing"];
    }else{
      $data["metabing"] = "";
    }

    if(!empty($webConfig["googlewebmaster"])){
      $data["googlewebmaster"] = $webConfig["googlewebmaster"];
    }else{
      $data["googlewebmaster"] = "";
    }

    if(!empty($webConfig["googleanalytics"])){
      $data["googleanalytics"] = $webConfig["googleanalytics"];
    }else{
      $data["googleanalytics"] = "";
    }

    return json_decode(json_encode($data));
  }

  public function updateConfig(){
    $updateConfig = $this->conn->prepare("UPDATE webconfig SET statusmt = :statusmt, recaptchasecret = :recaptchasecret, recaptchasite = :recaptchasite, titleweb = :titleweb, titlehead = :titlehead, metaauthor = :metaauthor, metadesc = :metadesc, alexarank = :alexarank, metabing = :metabing, googlewebmaster = :googlewebmaster, googleanalytics = :googleanalytics WHERE 1");
    $updateConfig->execute([
      "statusmt" => $this->statusmt,
      "recaptchasecret" => $this->recaptchasecret,
      "recaptchasite" => $this->recaptchasite,
      "titleweb" => $this->titleweb,
      "titlehead" => $this->titlehead,
      "metaauthor" => $this->metaauthor,
      "metadesc" => $this->metadesc,
      "alexarank" => $this->alexarank,
      "metabing" => $this->metabing,
      "googlewebmaster" => $this->googlewebmaster,
      "googleanalytics" => $this->googleanalytics
    ]);
  }

  public function updateConfWeb(){
    $updateConfWeb = $this->conn->prepare("UPDATE webconfig SET titleweb = :titleweb, titlehead = :titlehead, statusmt = :statusmt, recaptchasecret = :recaptchasecret, recaptchasite = :recaptchasite, googleanalytics = :googleanalytics WHERE 1");
    $updateConfWeb->execute([":titleweb" => $this->titleweb, "titlehead" => $this->titlehead, "statusmt" => $this->statusmt, "recaptchasecret" => $this->recaptchasecret, "recaptchasite" => $this->recaptchasite, "googleanalytics" => $this->googleanalytics]);
  }

  public function UpdateConfSeo(){
    $updateConfSeo = $this->conn->prepare("UPDATE webconfig SET metaauthor = :metaauthor, metadesc = :metadesc, metakeyword = :metakeyword, alexarank = :alexarank, metabing = :metabing, googlewebmaster = :googlewebmaster WHERE 1");
    $updateConfSeo->execute(["metaauthor" => $this->metaauthor, "metadesc" => $this->metadesc, "metakeyword" => $this->metakeyword, "alexarank" => $this->alexarank, "metabing" => $this->metabing, "googlewebmaster" => $this->googlewebmaster]);
  }

  public function _alert($classalert,$msg){
    return "<div class='alert alert-$classalert'>$msg</div>";
  }

  public function totalHal(){
    return ceil($this->totalData/$this->showPage);
  }

  public function BuildQueryURL(){
    return http_build_query($this->urlQuery);
  }
}

class validator extends blog{
  public $_response;

  public function __construct(){
    parent::__construct();
  }

  public function emailValid(){
    if(preg_match("/^[A-z]+[0-9]*[\@]{1}[A-z]+\.[A-z]{2,3}$/",$this->email) == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function checkSymbol($text_val){
    if(preg_match("#[\!\@\$\%\^\&\*\(\)\_\+\;\,\.\?\-\']#",$text_val) == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function recaptcha(){
    $recaptcha = "https://www.google.com/recaptcha/api/siteverify";
    $recaptcha = file_get_contents($recaptcha."?secret=".$this->recaptchasecret."&response=".$this->_response);
    $recaptcha = json_decode($recaptcha);

    if($recaptcha->success == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function ValidatorTemplateSymbol($templateVal){
    if(preg_match("/\<(\?|\?php|form|html|title|style|script)+/",$templateVal) == 1){
      return 1;
    }else{
      return 0;
    }
  }
}

class funcUser extends blog{
  public function __construct($typeUser=1){
    parent::__construct();
    $this->typeuser = $typeUser;
  }


  public function emailAlready(){
    $emailAlready = $this->conn->prepare("SELECT * FROM users WHERE email = :email");
    $emailAlready->execute(["email" => $this->email]);

    if($emailAlready->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function userAlready(){
    $userAlready = $this->conn->prepare("SELECT * FROM users WHERE username = :username");
    $userAlready->execute(["username" => $this->users]);
    
    if($userAlready->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function infoUser(){
    $infoUser = $this->conn->prepare("SELECT * FROM users WHERE username = :username");
    $infoUser->execute(["username" => $this->users]);
    return $infoUser->fetch();
  }

  public function addUser(){
    $maxiduser = $this->conn->prepare("SELECT MAX(userid) AS maxid FROM users");
    $maxiduser->execute();
    $maxiduser = $maxiduser->fetch();
    $maxiduser = $maxiduser["maxid"] + 1;

    $addUser = $this->conn->prepare("INSERT INTO users (userid, typeuser, username, email, password, status, ipaddress) VALUES (:userid, :typeuser, :username, :email, :password, :status, :ipaddress)");
    $addUser->execute(["userid" => $maxiduser, "typeuser" => $this->typeuser, "username" => $this->users, "email" => $this->email, "password" => $this->pass, "status" => $this->status_user, "ipaddress" => $this->ipaddress]);
  }

  public function editUser(){
    $editUser = $this->conn->prepare("UPDATE users SET email = :email, password = :password WHERE userid = :userid");
    $editUser->bindValue(":email",$this->email,PDO::PARAM_STR);
    $editUser->bindValue(":password",$this->newPass,PDO::PARAM_STR);
    $editUser->bindValue(":userid",$this->userid,PDO::PARAM_INT);
    $editUser->execute();
  }

  public function checkSession(){
    $checkSession = $this->conn->prepare("SELECT * FROM users WHERE username = :username AND password = :password");
    $checkSession->execute(["username" => $this->users, "password" => $this->pass]);

    if($checkSession->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function deleteUser(){
    $deleteUser = $this->conn->prepare("DELETE FROM users WHERE userid = :userid");
    $deleteUser->execute(["userid" => $this->userid]);
  }
}

class article extends blog{
  public function __construct(){
    parent::__construct();
  }

  public function infoCat(){
    $infoCat = $this->conn->prepare("SELECT * FROM category WHERE catid = :catid");
    $infoCat->bindValue(":catid",$this->catID,PDO::PARAM_INT);
    $infoCat->execute();
    return $infoCat->fetch();
  }
  
  public function addCat(){
    $maxCatID = $this->conn->prepare("SELECT MAX(catid) AS maxid FROM category");
    $maxCatID->execute();
    $maxCatID = $maxCatID->fetch();
    $maxCatID = $maxCatID["maxid"] + 1;
    
    $addCat = $this->conn->prepare("INSERT INTO category (catid, catname, status) VALUES (:catid, :catname, :status)");
    $addCat->bindValue(":catid",$maxCatID,PDO::PARAM_INT);
    $addCat->bindValue(":catname",$this->category,PDO::PARAM_STR);
    $addCat->bindValue(":status",$this->catStatus,PDO::PARAM_STR);
    $addCat->execute();
  }

  public function listCatData(){
    $listCatData = $this->conn->prepare("SELECT * FROM category WHERE catname LIKE :catname ORDER BY catid DESC LIMIT :limitOffset,:showPage");
    $listCatData->bindValue(":catname",$this->category,PDO::PARAM_STR);
    $listCatData->bindValue(":limitOffset",(int)$this->limitOffset,PDO::PARAM_INT);
    $listCatData->bindValue(":showPage",(int)$this->showPage,PDO::PARAM_INT);
    $listCatData->execute();
    return $listCatData->fetchAll(PDO::FETCH_ASSOC);
  }

  public function totalPostCat(){
    $totalPostCat = $this->conn->prepare("SELECT * FROM post WHERE category = :category");
    $totalPostCat->bindValue(":category",$this->catID,PDO::PARAM_INT);
    $totalPostCat->execute();
    return $totalPostCat->rowCount();
  }

  public function totalDataCat(){
    $totalDataCat = $this->conn->prepare("SELECT * FROM category WHERE catname LIKE :catname");
    $totalDataCat->bindValue(":catname",$this->category,PDO::PARAM_STR);
    $totalDataCat->execute();
    return $totalDataCat->rowCount();
  }

  public function validCatID(){
    $validCatID = $this->conn->prepare("SELECT * FROM category WHERE catid = :catid");
    $validCatID->bindValue(":catid",$this->category,PDO::PARAM_STR);
    $validCatID->execute();
    if($validCatID->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function deleteCat(){
    $deleteCat = $this->conn->prepare("DELETE FROM category WHERE catid = :catid");
    $deleteCat->bindValue(":catid",(int)$this->catID,PDO::PARAM_INT);
    $deleteCat->execute();
  }

  public function listCatTemp(){
    $listCatTemp = $this->conn->prepare("SELECT * FROM category");
    $listCatTemp->execute();
    return $listCatTemp->fetchAll(PDO::FETCH_ASSOC);
  }

  public function addPost(){
    $maxPostID = $this->conn->prepare("SELECT MAX(postid) AS maxid FROM post");
    $maxPostID->execute();
    $maxPostID = $maxPostID->fetch();
    $maxPostID = $maxPostID["maxid"] + 1;

    $addPost = $this->conn->prepare("INSERT INTO post (postid, posttitle, author, postcontent, status, visitor, thumbnail, tanggal, category) VALUES (:postid, :posttitle, :author, :postcontent, :status, :visitor, :thumbnail, :tanggal, :category)");
    $addPost->bindValue(":postid",$maxPostID,PDO::PARAM_INT);
    $addPost->bindValue(":posttitle",$this->postTitle,PDO::PARAM_STR);
    $addPost->bindValue(":author",$this->author,PDO::PARAM_STR);
    $addPost->bindValue(":postcontent",$this->postContent,PDO::PARAM_STR);
    $addPost->bindValue(":status",$this->postStatus,PDO::PARAM_INT);
    $addPost->bindValue(":visitor",$this->visitor,PDO::PARAM_STR);
    $addPost->bindValue(":thumbnail",$this->imgName,PDO::PARAM_STR);
    $addPost->bindValue(":tanggal",$this->tanggal,PDO::PARAM_INT);
    $addPost->bindValue(":category",$this->category,PDO::PARAM_STR);
    $addPost->execute();

    move_uploaded_file($this->imgTemp,"../img/".$this->imgName);
  }

  public function listPost(){
    $listPostData = $this->conn->prepare("SELECT * FROM post WHERE posttitle LIKE :posttitle AND category LIKE :category AND status LIKE :status ORDER BY postid DESC LIMIT :limitoffset,:showpage");
    $listPostData->bindValue(":posttitle",$this->postTitle,PDO::PARAM_STR);
    $listPostData->bindValue(":category",$this->category,PDO::PARAM_STR);
    $listPostData->bindValue(":status",$this->postStatus,PDO::PARAM_STR);
    $listPostData->bindValue(":limitoffset",$this->limitOffset,PDO::PARAM_INT);
    $listPostData->bindValue(":showpage",(int)$this->showPage,PDO::PARAM_INT);
    $listPostData->execute();
    return $listPostData->fetchAll(PDO::FETCH_ASSOC);
  }

  public function totalPostData(){
    $totalPostData = $this->conn->prepare("SELECT * FROM post WHERE posttitle LIKE :posttitle AND category LIKE :category AND status LIKE :status");
    $totalPostData->bindValue(":posttitle",$this->postTitle,PDO::PARAM_STR);
    $totalPostData->bindValue(":category",$this->category,PDO::PARAM_STR);
    $totalPostData->bindValue("status",$this->postStatus,PDO::PARAM_STR);
    $totalPostData->execute();
    return $totalPostData->rowCount();
  }

  public function deletePost(){
    $deletePost = $this->conn->prepare("DELETE FROM post WHERE postid = :postid");
    $deletePost->bindValue(":postid",$this->postID,PDO::PARAM_STR);
    $deletePost->execute();
  }

  public function validPostID(){
    $validPostID = $this->conn->prepare("SELECT * FROM post WHERE postid = :postid");
    $validPostID->bindValue(":postid",$this->postID,PDO::PARAM_STR);
    $validPostID->execute();
    if($validPostID->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function infoPost(){
    $infoPost = $this->conn->prepare("SELECT * FROM post WHERE postid = :postid");
    $infoPost->bindValue(":postid",$this->postID,PDO::PARAM_INT);
    $infoPost->execute();
    return $infoPost->fetch();
  }

  public function infoPageByTitle(){
    $infoPageByTitle = $this->conn->prepare("SELECT * FROM pages WHERE pagetitle = :pagetitle");
    $infoPageByTitle->bindValue(":pagetitle",$this->pageTitle,PDO::PARAM_STR);
    $infoPageByTitle->execute();
    return $infoPageByTitle->fetch();
  }

  public function validPageTitle(){
    $validPageTitle = $this->conn->prepare("SELECT * FROM pages WHERE pagetitle = :pagetitle");
    $validPageTitle->bindValue(":pagetitle",$this->pageTitle,PDO::PARAM_STR);
    $validPageTitle->execute();
    if($validPageTitle->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function updatePost(){
    $updatePost = $this->conn->prepare("UPDATE post SET posttitle = :posttitle, postcontent = :postcontent, category = :category WHERE postid = :postid");
    $updatePost->bindValue(":posttitle",$this->postTitle,PDO::PARAM_STR);
    $updatePost->bindValue(":postcontent",$this->postContent,PDO::PARAM_STR);
    $updatePost->bindValue(":category",$this->category,PDO::PARAM_INT);
    $updatePost->bindValue(":postid",$this->postID,PDO::PARAM_INT);
    $updatePost->execute();
  }

  public function validPostTitle(){
    $validPostTitle = $this->conn->prepare("SELECT * FROM post WHERE posttitle = :posttitle");
    $validPostTitle->bindValue(":posttitle",$this->postTitle,PDO::PARAM_STR);
    $validPostTitle->execute();
    if($validPostTitle->rowCount() >= 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function infoPostByTitle(){
    $infoPostByTitle = $this->conn->prepare("SELECT * FROM post WHERE posttitle = :posttitle");
    $infoPostByTitle->bindValue(":posttitle",$this->postTitle,PDO::PARAM_STR);
    $infoPostByTitle->execute();
    return $infoPostByTitle->fetch();
  }

  public function visitor(){
    $visitorLast = $this->conn->prepare("SELECT MAX(visitor) AS maxvisit FROM post");
    $visitorLast->execute();
    $visitorLast = $visitorLast->fetch();
    $visitorLast = $visitorLast["maxvisit"] + 1;

    $visitor = $this->conn->prepare("UPDATE post SET visitor = :visitor WHERE postid = :postid");
    $visitor->bindValue(":visitor",$visitorLast,PDO::PARAM_INT);
    $visitor->bindValue(":postid",$this->postID,PDO::PARAM_INT);
    $visitor->execute();
  }

  public function addComment(){
    $this->commentID = $this->conn->prepare("SELECT MAX(commentid) AS maxid FROM comment");
    $this->commentID->execute();
    $this->commentID = $this->commentID->fetch();
    $this->commentID = $this->commentID["maxid"] + 1;

    $addComment = $this->conn->prepare("INSERT INTO comment (commentid, postid, name, commentcontent, tanggal) VALUES (:commentid, :postid, :name, :commentcontent, :tanggal)");
    $addComment->bindValue(":commentid",$this->commentID,PDO::PARAM_INT);
    $addComment->bindValue(":postid",$this->postID,PDO::PARAM_INT);
    $addComment->bindValue(":name",$this->name,PDO::PARAM_STR);
    $addComment->bindValue(":commentcontent",$this->commentContent,PDO::PARAM_STR);
    $addComment->bindValue(":tanggal",$this->tanggal,PDO::PARAM_INT);
    $addComment->execute();
  }

  public function listComment(){
    $listComment = $this->conn->prepare("SELECT * FROM comment WHERE postid = :postid ORDER BY tanggal ASC");
    $listComment->bindValue(":postid",$this->postID,PDO::PARAM_INT);
    $listComment->execute();
    return $listComment->fetchAll(PDO::FETCH_ASSOC);
  }

  public function listTopPost($show){
    $listTopPost = $this->conn->prepare("SELECT * FROM post ORDER BY visitor DESC LIMIT 0,:show");
    $listTopPost->bindValue(":show",$show,PDO::PARAM_INT);
    $listTopPost->execute();
    return $listTopPost->fetchAll(PDO::FETCH_ASSOC);
  }

  public function latestComment($show){
    $latestComment = $this->conn->prepare("SELECT * FROM comment ORDER BY tanggal DESC LIMIT 0,:show");
    $latestComment->bindValue(":show",$show,PDO::PARAM_INT);
    $latestComment->execute();
    return $latestComment->fetchAll(PDO::FETCH_ASSOC);
  }
}

class template extends blog{
  public function __construct(){
    parent::__construct();
  }

  public function infoTemplate(){
    $infoTemplate = $this->conn->prepare("SELECT * FROM template WHERE templateid = :templateid");
    $infoTemplate->execute(["templateid" => $this->templateID]);
    
    return $infoTemplate->fetch();
  }

  public function templateValidID(){
    $templateValidID = $this->conn->prepare("SELECT * FROM template WHERE templateid = :templateid");
    $templateValidID->execute(["templateid" => $this->templateID]);
    
    if($templateValidID->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function listDataTemp(){
    $listDataTemp = $this->conn->prepare("SELECT * FROM template ORDER BY templateid DESC");
    $listDataTemp->execute();
    return $listDataTemp->fetchAll(PDO::FETCH_ASSOC);
  }

  public function templateUpdate(){
    $templateUpdate = $this->conn->prepare("UPDATE template SET templatecontent = :templateContent WHERE templateid = :templateid");
    $templateUpdate->execute(["templateContent" => $this->templateContent, "templateid" => $this->templateID]);
  }

}

class page extends blog{
  public function __construct(){
    parent::__construct();
  }
  public function validPageID(){
    $validPageID = $this->conn->prepare("SELECT * FROM pages WHERE pageid = :pageid");
    $validPageID->bindValue(":pageid",$this->pageID,PDO::PARAM_STR);
    $validPageID->execute();

    if($validPageID->rowCount() == 1){
      return 1;
    }else{
      return 0;
    }
  }

  public function infoPage(){
    $infoPage = $this->conn->prepare("SELECT * FROM pages WHERE pageid = :pageID");
    $infoPage->bindValue(":pageID",$this->pageID,PDO::PARAM_INT);
    $infoPage->execute();
    return $infoPage->fetch();
  }

  public function addPage(){
    $maxIDpage = $this->conn->prepare("SELECT MAX(pageid) AS maxid FROM pages");
    $maxIDpage->execute();
    $maxIDpage = $maxIDpage->fetch();
    $maxIDpage = $maxIDpage["maxid"] + 1;

    $addPage = $this->conn->prepare("INSERT INTO pages (pageid, pagetitle, pagecontent, pagestatus) VALUES (:pageid, :pagetitle, :pagecontent, :pagestatus)");
    $addPage->execute(["pageid" => $maxIDpage, "pagetitle" => $this->pageTitle, "pagecontent" => $this->pageContent, "pagestatus" => $this->pageStatus]);
  }

  public function listPageData(){
    $listPageData = $this->conn->prepare("SELECT * FROM Pages WHERE pagetitle LIKE :pagetitle AND pagestatus LIKE :pagestatus ORDER BY pageid DESC LIMIT :limitoffset,:showpage");
    $listPageData->bindValue(":pagetitle",$this->pageTitle,PDO::PARAM_STR);
    $listPageData->bindValue(":pagestatus",$this->pageStatus,PDO::PARAM_STR);
    $listPageData->bindValue(":limitoffset",(int)$this->limitOffset,PDO::PARAM_INT);
    $listPageData->bindValue(":showpage",(int)$this->showPage,PDO::PARAM_INT);
    $listPageData->execute();
    return $listPageData->fetchAll();
  }

  public function totalDataPage(){
    $totalDataPage = $this->conn->prepare("SELECT * FROM pages WHERE pagetitle LIKE :pagetitle AND pagestatus LIKE :pagestatus");
    $totalDataPage->bindValue(":pagetitle",$this->pageTitle,PDO::PARAM_STR);
    $totalDataPage->bindValue(":pagestatus",$this->pageStatus,PDO::PARAM_STR);
    $totalDataPage->execute();
    return $totalDataPage->rowCount();
  }

  public function deletePage(){
    $deletePage = $this->conn->prepare("DELETE FROM pages WHERE pageid = :pageid");
    $deletePage->bindValue(":pageid",$this->pageID,PDO::PARAM_STR);
    $deletePage->execute();
  }

  public function updatePage(){
    $updatePage = $this->conn->prepare("UPDATE pages SET pagetitle = :pagetitle, pagecontent = :pagecontent WHERE pageid = :pageid");
    $updatePage->bindValue(":pagetitle",$this->pageTitle,PDO::PARAM_STR);
    $updatePage->bindValue(":pagecontent",$this->pageContent,PDO::PARAM_STR);
    $updatePage->bindValue(":pageid",$this->pageID,PDO::PARAM_STR);
    $updatePage->execute();
  }
}
?>
