<?php
require_once("conf/func.class.php");

$templateClass = new template();
$articleClass = new article();
$validator = new validator();

$templateClass->templateID = 1;
$infoTemplate = $templateClass->infoTemplate();
$webConf = $templateClass->webConfig();

if($webConf->statusmt == 1){
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="index, follow">
    <meta name="description" content="<?=$webConf->metadesc?>">
    <meta name="author" content="<?=$webConf->metaauthor?>">
    <meta name="keywords" content="<?=$webConf->metakeyword?>">
    <meta name="alexaVerifyID" content="<?=$webConf->alexarank?>">
    <meta name="msvalidate.01" content="<?=$webConf->metabing?>"> <!-- Bing -->
    <meta name="google-site-verification" content="<?=$webConf->googlewebmaster?>"> <!-- Google webmaster -->

    <title>Blog Home - <?=$webConf->titleweb?></title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-home.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="./"><?=$webConf->titlehead?></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <?=$infoTemplate["templatecontent"]?>
          </ul>
        </div>
      </div>
    </nav>
    <br>
    <!-- Page Content -->
    <div class="container">
      <form method="get">
        <?php
        if(!empty($_GET["category"])){
          echo "<input type='hidden' value='".$_GET["category"]."' name='category' />";
        }
        ?>
      <div class="row">
        <div class="col-lg-12">
          <div class="input-group">
            <input type="text" name="search" class="form-control form-control-lg" value="<?=@$_GET["search"]?>" placeholder="Search for...">
              <span class="input-group-btn">
                <button class="btn btn-secondary btn-lg" type="submit">Go!</button>
              </span>
          </div>
        </div>
      </div>
      </form>
      <br>
      <?php
      $articleClass->showPage = 5;
      $articleClass->hal = (!empty($_GET["hal"]) AND is_numeric($_GET["hal"]) AND $validator->checkSymbol($_GET["hal"]) != 1 AND @$_GET["hal"] >= 2) ? $_GET["hal"] - 1 : 0 ;
      $articleClass->limitOffset = $articleClass->hal * $articleClass->showPage;

      // use category and title //
      $articleClass->category = (!empty($_GET["category"]) AND is_numeric($_GET["category"]) AND $validator->checkSymbol($_GET["category"]) != 1 AND $_GET["category"] >= 1) ? htmlentities(strip_tags(trim($_GET["category"]))) : "%%";
      $articleClass->postTitle = (!empty($_GET["search"]) AND $validator->checkSymbol($_GET["search"]) != 1) ? htmlentities(strip_tags($_GET["search"])) : "%%";
      /////////////////////////////
      $articleClass->postStatus = "%%";

      $articleClass->totalData = $articleClass->totalPostData();
      $articleClass->totalHal = $articleClass->totalHal();
      ?>
      <div class="row">

        <!-- Blog Entries Column -->
        <div class="col-md-8">
          <?php
          if(!empty($articleClass->listPost())){
            foreach($articleClass->listPost() as $data){
          ?>
          <!-- Blog Post -->
          <div class="card mb-4">
            <img class="card-img-top" src="./img/<?=$data["thumbnail"]?>" alt="Card image cap">
            <div class="card-body">
              <h2 class="card-title"><?=$data["posttitle"]?></h2>
              <p class="card-text"><?=substr(strip_tags($data["postcontent"]),0,200)?></p>
              <a href="./post.php?p=<?=preg_replace("/ /","-",$data["posttitle"])?>" class="btn btn-primary">Read More &rarr;</a>
            </div>
            <div class="card-footer text-muted">
              Posted on <?=date("M d, Y",$data["tanggal"])?> by
              <a href="#"><?=$data["author"]?></a>
            </div>
          </div>
          <?php
            }
          }else{
            echo "<h1 class='text-center'>404 Not Found.</h1>";
          }
          ?>
          
          <!-- Pagination -->
          <ul class="pagination justify-content-center mb-4">
            <?php
            if($articleClass->totalHal >= 2){

              if($articleClass->totalHal <= 1 OR @$_GET["hal"] >= $articleClass->totalHal){
                echo "<li class='page-item disabled'><a class='page-link' href='#'>&larr; Older</a></li>";
              }elseif($articleClass->totalHal >= 2){
                if(empty($_GET["hal"]) OR @$_GET["hal"] <= 1){
                  $articleClass->urlQuery = ["category" => @$_GET["category"], "search" => @$_GET["search"], "hal" => 2];
                  $articleClass->urlQuery = $articleClass->BuildQueryURL();
                  echo "<li class='page-item'><a class='page-link' href='./index.php?".$articleClass->urlQuery."'>&larr; Older</a></li>";
                }elseif(is_numeric($_GET["hal"]) AND $validator->checkSymbol($_GET["hal"]) != 1 AND $_GET["hal"] >= 2){
                  $articleClass->urlQuery = ["category" => @$_GET["category"], "search" => @$_GET["search"], "hal" => $_GET["hal"] + 1];
                  $articleClass->urlQuery = $articleClass->BuildQueryURL();
                  echo "<li class='page-item'><a class='page-link' href='./index.php?".$articleClass->urlQuery."'>&larr; Older</a></li>";
                }else{
                  echo "<li class='page-item disabled'><a class='page-link' href='#'>&larr; Older</a></li>";
                }
              }

              if(empty($_GET["hal"]) OR $validator->checkSymbol($_GET["hal"]) == 1 OR !is_numeric($_GET["hal"])){
                echo "<li class='page-item disabled'><a class='page-link' href='#'>Newer &rarr;</a></li>";
              }elseif($_GET["hal"] >= 2){
                $articleClass->urlQuery = ["category" => @$_GET["category"], "search" => @$_GET["search"], "hal" => $_GET["hal"] - 1];
                $articleClass->urlQuery = $articleClass->BuildQueryURL();
                echo "<li class='page-item'><a class='page-link' href='./index.php?".$articleClass->urlQuery."'>Newer &rarr;</a></li>";
              }else{
                echo "<li class='page-item disabled'><a class='page-link' href='#'>Newer &rarr;</a></li>";
              }
            }
            ?>
          </ul>

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Categories Widget -->
          <div class="card my-4">
            <h5 class="card-header">Categories</h5>
            <div class="card-body">
              <div class="row">
                <div class="col-lg-12">
                  <ul class="list-unstyled mb-0">
                    <?php
                    foreach($articleClass->listCatTemp() as $data){
                      echo "
                      <li>
                        <a href='./index.php?category=".$data["catid"]."'>".$data["catname"]."</a>
                      </li>
                      ";
                    }
                    ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; <?=$webConf->titlehead?> <?=date("Y")?></p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
<?php
}else{
    header("location:maintance.php");
}
?>