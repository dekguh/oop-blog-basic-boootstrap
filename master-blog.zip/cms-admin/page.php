<?php
require_once("../conf/func.class.php");
$userClass = new funcUser();
$pageClass = new page();
$validator = new validator();
$webconfig = $userClass->webConfig();

$userClass->users = htmlentities(strip_tags(trim(@$_SESSION["ses_user"])));
$userClass->pass = htmlentities(strip_tags(trim(@$_SESSION["ses_pass"])));

if($userClass->checkSession() == 1){

  if(@$_GET["act"] == "logout"){
    session_destroy();
    header("location:login.php");
  }

  if(@$_GET["page"] == "delete" AND !empty($_GET["pageid"]) AND $validator->checkSymbol($_GET["pageid"]) != 1){
    $pageClass->pageID = htmlentities(strip_tags(trim($_GET["pageid"])));
    if($pageClass->validPageID() == 1){
      $pageClass->deletePage();
    }
  }

  if(@$_POST["deleteBtn"]){
    $listIDpage = $_POST["listIDpage"];
    if(!empty($listIDpage)){
      for($i=0;$i<count($listIDpage);$i++){
        if(is_numeric($listIDpage[$i])){
          $pageClass->pageID = $listIDpage[$i];
          $pageClass->deletePage();
        }
      }
    }
  }
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=$webconfig->titleweb?> | Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="./"><?=$webconfig->titlehead?></a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="./">
            <i class="fas fa-fw fa-home"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-newspaper"></i>
            <span>Post</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./post.php?page=create">Make Post</a>
            <a class="dropdown-item" href="./post.php">List Post</a>
            <a class="dropdown-item" href="./post.php?page=category">Category</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-print"></i>
            <span>Page</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./page.php?page=create">Make Page</a>
            <a class="dropdown-item" href="./page.php">List Page</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-cog"></i>
            <span>Settings</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./setting.php?page=web">Web Settings</a>
            <a class="dropdown-item" href="./setting.php?page=seo">Seo Settings</a>
          </div>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./template.php">
            <i class="fas fa-fw fa-pencil-alt"></i>
            <span>Template</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./index.php?act=logout">
            <i class="fas fa-fw fa-long-arrow-alt-right"></i>
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">
            <?php
            if(@$_GET["page"] == "create"){

              if(@$_POST["btnAdd"]){
                $pageClass->pageContent = $_POST["contentpage"];
                $pageClass->pageStatus = 1;
                $pageClass->pageTitle = htmlentities(strip_tags($_POST["pagetitle"]));
                if(!empty($pageClass->pageContent) AND !empty($pageClass->pageTitle)){
                  if(preg_match("/\.(\?|\?php)/",$pageClass->pageContent) != 1 AND $validator->checkSymbol($pageClass->pageTitle) != 1 AND preg_match("/\.(\?|\?php)/",$pageClass->pageTitle) != 1){
                    if(strlen($pageClass->pageTitle) >= 4 AND strlen($pageClass->pageTitle) <= 20){
                      $pageClass->addPage();
                      $pageClass->msgErr = $pageClass->_alert("info","Added Page Success.");
                    }else{
                      $pageClass->msgErr = $pageClass->_alert("danger","Title minimal 6 char and maximal 20 char.");
                    }
                  }else{
                    $pageClass->msgErr = $pageClass->_alert("danger","Don't use tag php and Symbol in Title.");
                  }
                }else{
                  $pageClass->msgErr = $pageClass->_alert("danger","All form must filled.");
                }
              }
            ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">Tes</div>
                        <div class="card-body">
                            <?=@$pageClass->msgErr?>
                            <form method="post">
                              <div class="row">
                                <div class="col-lg-12">
                                  <div class="form-group">
                                    <label class="form-label">Title Page</label>
                                    <input type="text" maxlength="20" class="form-control form-control-lg" name="pagetitle" />
                                  </div>
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-lg-12">
                                  <div class="from-group">
                                    <label class="form-label">Content Page</label>
                                    <textarea id="summernote" name="contentpage"></textarea>
                                  </div>
                                </div>
                              </div>
                              <br>
                              <div class="row">
                                <div class="col-lg-3"></div>
                                <div class="col-lg-3">
                                  <div class="form-group">
                                    <input type="submit" class="btn btn-info btn-block btn-lg" name="btnAdd" value="Add" />
                                  </div>
                                </div>
                                <div class="col-lg-3">
                                  <div class="form-group">
                                    <input type="reset" class="btn btn-warning btn-block btn-lg" name="btnReset" value="Reset" />
                                  </div>
                                </div>
                                <div class="col-lg-3"></div>
                              </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            }elseif(@$_GET["page"] == "edit" AND !empty($_GET["pageid"]) AND is_numeric($_GET["pageid"]) AND $validator->checkSymbol($_GET["pageid"]) != 1){
              $pageClass->pageID = htmlentities(trim(strip_tags($_GET["pageid"])));
              if($pageClass->validPageID() == 1){
                $infoPage = $pageClass->infoPage();

                if(@$_POST["btnEdit"]){
                  $pageClass->pageTitle = htmlentities(strip_tags($_POST["title"]));
                  $pageClass->pageContent = htmlentities($_POST["pagecontent"]);

                  if(!empty($pageClass->pageTitle) AND !empty($pageClass->pageContent)){
                    if($validator->ValidatorTemplateSymbol($pageClass->pageContent) != 1 AND $validator->checkSymbol($pageClass->pageTitle) != 1){
                      if(strlen($pageClass->pageTitle) >= 4 AND strlen($pageClass->pageTitle) <= 20){
                        $pageClass->updatePage();
                        $pageClass->msgErr = $pageClass->_alert("info","Success update Page.");
                        $infoPage = $pageClass->infoPage();
                      }else{
                        $pageClass->msgErr = $pageClass->_alert("danger","title minimal 4 char and maximal 4 char.");
                      }
                    }else{
                      $pageClass->msgErr = $pageClass->_alert("danger","dont use symbol php in content and symbol in title.");
                    }
                  }else{
                    $pageClass->msgErr = $pageClass->_alert("danger","All form must filled.");
                  }
                }
            ?>
              <div class="row">
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-header">Edit Page</div>
                    <div class="card-body">
                    <?=@$pageClass->msgErr?>
                      <form method="post">
                        <div class="row">
                          <div class="col-lg-12">
                            <div class="form-group">
                              <label class="form-label">Page Title</label>
                              <input type="text" class="form-control form-control-lg" value="<?=$infoPage["pagetitle"]?>" name="title" value="" />
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-lg-12">
                            <label class="form-label">Content</label>
                            <textarea id="summernote" name="pagecontent"><?=$infoPage["pagecontent"]?></textarea>
                          </div>
                        </div>
                        <br>
                        <div class="row">
                          <div class="col-lg-3"></div>
                          <div class="col-lg-3">
                            <input type="submit" class="btn btn-info btn-block btn-lg" value="Edit" name="btnEdit" />
                          </div>
                          <div class="col-lg-3">
                            <input type="reset" class="btn btn-warning btn-block btn-lg" value="Reset" name="btnReset" />
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div
            <?php
              }else{
                header("location:page.php");
              }
            }else{
              $pageClass->showPage = 10;
              $pageClass->pageTitle = (!empty($_GET["title"]) AND $validator->checkSymbol($_GET["title"]) != 1) ? "%".htmlentities(strip_tags($_GET["title"]))."%" : "%%";
              $pageClass->pageStatus = (!empty($_GET["pagestatus"]) AND is_numeric($_GET["pagestatus"]) AND $validator->checkSymbol($_GET["pagestatus"]) != 1 AND @$_GET["Pagestatus"] >= 1 AND @$_GET["pagestatus"] <= 1) ? "%".htmlentities(strip_tags($_GET["pagestatus"]))."%" : "%%";
              $pageClass->hal = (!empty($_GET["hal"]) AND is_numeric($_GET["hal"]) AND $validator->checkSymbol($_GET["hal"]) != 1 AND $_GET["hal"] >= 1) ? htmlentities(strip_tags(trim($_GET["hal"]))) - 1 : 0;
              $pageClass->limitOffset = $pageClass->hal * $pageClass->showPage;
            ?>
            <div class="row">
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-body">
                      <form method="get">
                        <div class="row">
                          <div class="col-lg-4">
                            <div class="form-group">
                              <input type="text" class="form-control form-control-lg" value="<?=htmlentities(strip_tags(@$_GET["title"]))?>" name="title" placeholder="Title" />
                            </div>
                          </div>

                          <div class="col-lg-4">
                            <div class="form-group">
                              <select name="pagestatus" class="form-control form-control-lg">
                                <option value="">Status</option>
                                <?php
                                for($i=1;$i<=2;$i++){
                                  if($i == 1){
                                    $val = "active";
                                  }elseif($i == 2){
                                    $val = "nonactive";
                                  }

                                  if($_GET["pagestatus"] == $i){
                                    echo "<option value='$i' selected>$val</option>";
                                  }else{
                                    echo "<option value='$i'>$val</option>";
                                  }
                                }
                                ?>
                              </select>
                            </div>
                          </div>

                          <div class="col-lg-4">
                            <div class="form-group">
                              <input type="submit" class="btn btn-info btn-lg" name="btnSearch" value="Search" />
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
            </div>
            <br>
            <form method="post">
            <div class="row">
              <div class="col-lg-12">
                <table class="table table-bordered">
                  <tr>
                    <th width="2%">#</th>
                    <th>Page</th>
                    <th width="20%">Action</th>
                  </tr>
                  <?php
                  if(!empty($pageClass->listPageData())){
                    foreach($pageClass->listPageData() as $data){
                      echo "
                      <tr>
                        <td><input type='checkbox' name='listIDpage[]' value='".$data["pageid"]."' /></td>
                        <td><a href='./page.php?page=edit&content=".preg_replace("/ /","-",$data["pagetitle"])."&pageid=".$data["pageid"]."'>".$data["pagetitle"]."</a></td>
                        <td>
                          <a href='./page.php?page=edit&content=".preg_replace("/ /","-",$data["pagetitle"])."&pageid=".$data["pageid"]."'><i class='fas fa-edit fa-lg'></i></a>
                          <a href='./page.php?page=delete&pageid=".$data["pageid"]."'><i class='fas fa-trash fa-lg'></i></a>
                        </td>
                      </tr>
                      ";
                    }
                  }else{
                    echo "
                    <tr>
                      <td colspan='3' align='center'>Not found</td>
                    </tr>
                    ";
                  }
                  ?>
                </table>
              </div>
            </div>
            <?php
            if(!empty($pageClass->listPageData())){
            ?>
            <div class="row">
              <div class="col-lg-3">
                <input type="submit" name="deleteBtn" class="btn btn-danger btn-lg" value="Delete" />
              </div>
            </div>
            <?php
            }
            ?>
            </form>

            <div class="row">
              <div class="col-lg-4"></div>
              <div class="col-lg-4">
                <?php
                $pageClass->totalData = $pageClass->totalDataPage();
                $pageClass->totalHal = $pageClass->totalHal();
                $pageClass->selisih = ($pageClass->totalHal <= 3) ? $pageClass->totalHal : 3 ;
                
                $pageClass->start = (!empty($_GET["hal"]) AND $_GET["hal"] > $pageClass->selisih AND is_numeric($_GET["hal"]) AND $pageClass->totalHal > $pageClass->selisih) ? htmlentities(trim(strip_tags($_GET["hal"]))) - $pageClass->selisih : 1 ;
                
                if($pageClass->totalHal <= $pageClass->selisih OR $_GET["hal"] >= ($pageClass->totalHal - $pageClass->selisih)){
                  $pageClass->end = $pageClass->totalHal;
                }elseif($_GET["hal"] >= $pageClass->selisih OR $_GET["hal"] <= ($pageClass->totalHal - $pageClass->selisih)){
                  $pageClass->end = $_GET["hal"] + $pageClass->selisih;
                }else{
                  $pageClass->end = $pageClass->selisih;
                }

                if($pageClass->totalHal >= 2){
                ?>
                <ul class="pagination justify-content-center">
                <?php
                if(empty($_GET["hal"]) OR !is_numeric($_GET["hal"]) OR @$_GET["hal"] <= 1 AND $validator->checkSymbol(@$_GET["Hal"]) == 1){
                  echo "<li class='paginate_button page-item disabled'><a class='page-link' href='#'>First</a></li>";
                }elseif(is_numeric($_GET["hal"]) AND $_GET["hal"] >= 2){
                  $pageClass->urlQuery = ["title" => htmlentities(strip_tags(@$_GET["title"])), "pagestatus" => htmlentities(trim(strip_tags(@$_GET["pagestatus"]))), "hal" => 1];
                  $pageClass->urlQuery = $pageClass->buildQueryURL();
                  echo "<li class='paginate_button page-item'><a class='page-link' href='./page.php?$pageClass->urlQuery'>First</a></li>";
                }else{
                  echo "<li class='paginate_button page-item disabled'><a class='page-link' href='#'>First</a></li>";
                }

                for($i = $pageClass->start;$i <= $pageClass->end;$i++){
                  if(@$_GET["hal"] == $i){
                    echo "<li class='paginate_button page-item active'><a class='page-link' href='#'>$i</a></li>";
                  }elseif(empty($_GET["hal"]) AND $i == 1){
                    echo "<li class='paginate_button page-item active'><a class='page-link' href='#'>1</a></li>";
                  }else{
                    $pageClass->urlQuery = ["title" => htmlentities(strip_tags(@$_GET["title"])), "pagestatus" => htmlentities(trim(strip_tags(@$_GET["pagestatus"]))), "hal" => $i];
                    $pageClass->urlQuery = $pageClass->buildQueryURL();
                    echo "<li class='paginate_button page-item'><a class='page-link' href='./page.php?$pageClass->urlQuery'>$i</a></li>";
                  }
                }

                if($_GET["hal"] >= $pageClass->totalHal OR $pageClass->totalHal <= 1){
                  echo "<li class='paginate_button page-item disabled'><a class='page-link' href='#'>Last</a></li>";
                }else{
                  $pageClass->urlQuery = ["title" => htmlentities(strip_tags(@$_GET["title"])), "pagestatus" => htmlentities(trim(strip_tags(@$_GET["pagestatus"]))), "hal" => $pageClass->totalHal];
                  $pageClass->urlQuery = $pageClass->buildQueryURL();
                  echo "<li class='paginate_button page-item'><a class='page-link' href='./page.php?$pageClass->urlQuery'>Last</a></li>";
                }
                ?>
                </ul>
                <?php
                }
                ?>
              </div>
              <div class="col-lg-4"></div>
            </div>
            <?php
            }
            ?>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © <?=$webconfig->titlehead?> - <?=date("Y")?></span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    
    <!-- include summernote css/js -->
    <link href="dist/summernote-bs4.css" rel="stylesheet">
    <script src="dist/summernote-bs4.js"></script>

    <script>
      $(document).ready(function() {
        $('#summernote').summernote({
          height: 400
        });
      });
    </script>
  </body>

</html>

<?php
}else{
    header("location:login.php");
}
?>