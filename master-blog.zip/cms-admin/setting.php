<?php
require_once("../conf/func.class.php");
$userClass = new funcUser();
$webconfig = $userClass->webConfig();
$validator = new validator();

$userClass->users = htmlentities(strip_tags(trim(@$_SESSION["ses_user"])));
$userClass->pass = htmlentities(strip_tags(trim(@$_SESSION["ses_pass"])));

if($userClass->checkSession() == 1){

  if(@$_GET["act"] == "logout"){
    session_destroy();
    header("location:login.php");
  }

  if(@$_POST["btnEdit"]){
    $userClass->titleweb = htmlentities(strip_tags($_POST["titleweb"]));
    $userClass->titlehead = htmlentities(strip_tags($_POST["titlehead"]));
    $userClass->recaptchasecret = htmlentities(strip_tags(trim($_POST["recaptchasecret"])));
    $userClass->recaptchasite = htmlentities(strip_tags(trim($_POST["recaptchasite"])));
    $userClass->googleanalytics = htmlentities(strip_tags(trim($_POST["googleanalytics"])));
    $userClass->statusmt = htmlentities(trim(strip_tags(trim($_POST["statusmt"]))));

    if(!empty($userClass->titleweb) AND !empty($userClass->titlehead) AND !empty($userClass->recaptchasecret) AND !empty($userClass->recaptchasite) AND !empty($userClass->googleanalytics)){
      if(is_numeric($userClass->statusmt) AND $userClass->statusmt >= 1 AND $userClass->statusmt <= 2 AND $validator->checksymbol($userClass->statusmt) != 1){
        if(strlen($userClass->titleweb) >= 6 AND strlen($userClass->titleweb) <= 34 AND $validator->checksymbol($userClass->titleweb) != 1){
          if(strlen($userClass->titlehead) >= 4 AND strlen($userClass->titlehead) <= 12 AND $validator->checksymbol($userClass->titlehead) != 1){
            $userClass->updateConfWeb();
            $userClass->msgErr = $userClass->_alert("info","Update Config web success.");
            $webconfig = $userClass->webConfig();
          }else{
            $userClass->msgErr = $userClass->_alert("danger","Minimal 4 char and Max 12 Char without symbol for Title head.");
          }
        }else{
          $userClass->msgErr = $userClass->_alert("danger","Minimal 6 char and Max 34 Char without symbol for Title Web.");
        }
      }else{
        $userClass->msgErr = $userClass->_alert("danger","Value from status Maintance not valid.");
      }
    }else{
      $userClass->msgErr = $userClass->_alert("danger","All from must filled.");
    }
  }

  if(@$_POST["seoEdit"]){
    $userClass->metaauthor = htmlentities(strip_tags($_POST["metaauthor"]));
    $userClass->metadesc = htmlentities(strip_tags($_POST["metadesc"]));
    $userClass->metakeyword = htmlentities(strip_tags($_POST["metakeyword"]));
    $userClass->alexarank = htmlentities(strip_tags(trim($_POST["alexarank"])));
    $userClass->metabing = htmlentities(strip_tags(trim($_POST["metabing"])));
    $userClass->googlewebmaster = htmlentities(strip_tags(trim($_POST["googlewebmaster"])));

    if($validator->checksymbol($userClass->metaauthor) != 1){
      $userClass->UpdateConfSeo();
      $userClass->_alert("info","Update Config SEO success.");
      $webconfig = $userClass->webConfig();
    }else{
      $userClass->msgErr = $userClass->_alert("danger","Dont use symbol on Meta Author.");
    }
  }
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=htmlentities(strip_tags($webconfig->titleweb))?> | Settings</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="./"><?=htmlentities(strip_tags($webconfig->titlehead))?></a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="./">
            <i class="fas fa-fw fa-home"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-newspaper"></i>
            <span>Post</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./post.php?page=create">Make Post</a>
            <a class="dropdown-item" href="./post.php">List Post</a>
            <a class="dropdown-item" href="./post.php?page=category">Category</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-print"></i>
            <span>Page</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./page.php?page=create">Make Page</a>
            <a class="dropdown-item" href="./page.php">List Page</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-cog"></i>
            <span>Settings</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./setting.php?page=web">Web Settings</a>
            <a class="dropdown-item" href="./setting.php?page=seo">Seo Settings</a>
          </div>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./template.php">
            <i class="fas fa-fw fa-pencil-alt"></i>
            <span>Template</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./index.php?act=logout">
            <i class="fas fa-fw fa-long-arrow-alt-right"></i>
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">

        <?php
            if($_GET["page"] == "web"){
        ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">Web Settings</div>
                        <div class="card-body">
                          <?=@$userClass->msgErr?>
                            <form method="post">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Title Web: </label>
                                            <input type="text" class="form-control form-control-lg" value="<?=$webconfig->titleweb?>" name="titleweb" placeholder="Title Web" />
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Title Head: </label>
                                            <input type="text" class="form-control form-control-lg" value="<?=$webconfig->titlehead?>" name="titlehead" placeholder="Title Head" />
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                  <div class="col-lg-6">
                                    <div class="form-group">
                                      <label class="form-label">Google Site</label>
                                      <input type="text" name="recaptchasite" class="form-control form-control-lg" value="<?=$webconfig->recaptchasite?>" placeholder="Google Recaptcha Site" required/>
                                    </div>
                                  </div>

                                  <div class="col-lg-6">
                                    <div class="form-group">
                                      <label class="form-label">Google Secret</label>
                                      <input class="form-control form-control-lg" name="recaptchasecret" value="<?=$webconfig->recaptchasecret?>" placeholder="Google Recaptcha Secret" required/>
                                    </div>
                                  </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Google Analytics: </label>
                                            <input type="text" class="form-control form-control-lg" value="<?=$webconfig->googleanalytics?>" name="googleanalytics" placeholder="Google Analytics" />
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-label">Status Maintance</label>
                                            <select class="form-control" name="statusmt">
                                                <?php
                                                for($i=1;$i<=2;$i++){
                                                  if($i == 1){
                                                    $val = "No";
                                                  }elseif($i == 2){
                                                    $val = "Yes";
                                                  }

                                                  if($webconfig->statusmt == $i){
                                                    echo "<option value='$i' selected>$val</option>";
                                                  }else{
                                                    echo "<option value='$i'>$val</option>";
                                                  }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                  <div class="col-lg-3"></div>
                                  <div class="col-lg-3">
                                    <div class="form-group">
                                      <input type="submit" class="btn btn-info btn-block btn-lg" value="Edit" name="btnEdit" />
                                    </div>
                                  </div>
                                  <div class="col-lg-3">
                                    <div class="form-group">
                                      <input type="reset" class="btn btn-warning btn-block btn-lg" value="Reset" name="btnClear" />
                                    </div>
                                  </div>
                                  <div class="col-lg-3"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php
            }elseif($_GET["page"] == "seo"){
        ?>
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">SEO Settings</div>
              <div class="card-body">
                <form method="post">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Meta Author: </label>
                        <input type="text" class="form-control form-control-lg" value="<?=$webconfig->metaauthor?>" name="metaauthor" placeholder="" />
                      </div>
                    </div>

                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Meta description: </label>
                        <input type="text" class="form-control form-control-lg" value="<?=$webconfig->metadesc?>" name="metadesc" placeholder="" />
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Meta keyword: </label>
                        <input type="text" class="form-control form-control-lg" value="<?=$webconfig->metakeyword?>" name="metakeyword" placeholder="" />
                      </div>
                    </div>

                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Alexa rank: </label>
                        <input type="text" class="form-control form-control-lg" value="<?=$webconfig->alexarank?>" name="alexarank" placeholder="" />
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Bing search: </label>
                        <input type="text" class="form-control form-control-lg" value="<?=$webconfig->metabing?>" name="metabing" placeholder="" />
                      </div>
                    </div>

                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Google webmaster: </label>
                        <input type="text" class="form-control form-control-lg" value="<?=$webconfig->googlewebmaster?>" name="googlewebmaster" placeholder="" />
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-3">
                      <input type="submit" class="btn btn-info btn-block btn-lg" value="Edit" name="seoEdit" />
                    </div>
                    <div class="col-lg-3">
                      <input type="reset" name="seoReset" value="Reset" class="btn btn-warning btn-block btn-lg" />
                    </div>
                    <div class="col-lg-3"></div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <?php
            }else{
            header("location:index.php");
            }
        ?>

        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © <?=htmlentities(strip_tags($webconfig->titlehead))?> - <?=date("Y")?></span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

  </body>

</html>

<?php
}else{
    header("location:login.php");
}
?>