<?php
require_once("../conf/func.class.php");
$userClass = new funcUser();
$validator = new validator();
$webconfig = $userClass->webConfig();
$templateClass = new template();

$userClass->users = htmlentities(strip_tags(trim(@$_SESSION["ses_user"])));
$userClass->pass = htmlentities(strip_tags(trim(@$_SESSION["ses_pass"])));

if($userClass->checkSession() == 1){

  if(@$_GET["act"] == "logout"){
    session_destroy();
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=$webconfig->titleweb?> | Template Manager</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="./"><?=$webconfig->titlehead?></a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="./">
            <i class="fas fa-fw fa-home"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-newspaper"></i>
            <span>Post</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./post.php?page=create">Make Post</a>
            <a class="dropdown-item" href="./post.php">List Post</a>
            <a class="dropdown-item" href="./post.php?page=category">Category</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-print"></i>
            <span>Page</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./page.php?page=create">Make Page</a>
            <a class="dropdown-item" href="./page.php">List Page</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-cog"></i>
            <span>Settings</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./setting.php?page=web">Web Settings</a>
            <a class="dropdown-item" href="./setting.php?page=seo">Seo Settings</a>
          </div>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./template.php">
            <i class="fas fa-fw fa-pencil-alt"></i>
            <span>Template</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./index.php?act=logout">
            <i class="fas fa-fw fa-long-arrow-alt-right"></i>
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">
        <?php
        $templateClass->templateID = htmlentities(strip_tags(trim(@$_GET["templateid"])));
        if(!empty($templateClass->templateID) AND is_numeric($templateClass->templateID) AND $validator->checksymbol($templateClass->templateID) != 1 AND $templateClass->templateValidID() == 1){
          $templateInfo = $templateClass->infoTemplate();
          if(@$_POST["editBtn"]){
            $templateClass->templateContent = $_POST["codes"];
            if(!empty($templateClass->templateContent)){
              if($validator->ValidatorTemplateSymbol($templateClass->templateContent) == 0){
                if(strlen($templateClass->templateContent) >= 20){
                  $templateClass->templateUpdate();
                  $templateInfo = $templateClass->infoTemplate();
                }else{
                  $templateClass->msgErr = $templateClass->_alert("danger","Minimal 20 Character");
                }
              }else{
                $templateClass->msgErr = $templateClass->_alert("danger","Dont use symbol php and form.");
              }
            }else{
              $templateClass->msgErr = $templateClass->_alert("danger","All form must filled.");
            }
          }
        ?>
            <div class="row">
              <div class="col-lg-12">
                <div class="card">
                  <div class="card-header">Edit Template</div>
                  <div class="card-body">
                    <?=@$templateClass->msgErr?>
                    <form method="post">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label class="form-label">Code (using html only)</label>
                            <textarea class="form-control" name="codes" rows="20"><?=@$templateInfo["templatecontent"]?></textarea>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                            <div class="col-lg-3"></div>
                            <div class="col-lg-3">
                              <div class="form-group">
                                <input class="btn btn-info btn-lg btn-block" type="submit" value="Edit" name="editBtn" />
                              </div>
                            </div>
                            <div class="col-lg-3">
                            <div class="form-group">
                              <input class="btn btn-warning btn-block btn-lg" value="Reset" type="reset" name="resetBtn" />
                            </div>
                          </div>
                          <div class="col-lg-3"></div>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
        <?php
        }else{
        ?>
            <div class="row">
                <div class="col-lg-12">
                  <table class="table table-bordered">
                    <thead class="thead-dark">
                      <tr>
                        <th width="20%">name</th> <th>Description</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                        foreach($templateClass->listDataTemp() as $data){
                          echo "
                          <tr>
                            <td><a href='./template.php?templateid=".$data["templateid"]."'>".$data["templatename"]."</a></td>
                            <td>".$data["deskripsi"]."</td>
                          </tr>
                          ";
                        }
                      ?>
                    </tbody>
                  </table>
                </div>
            </div>
        <?php
        }
        ?>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © <?=$webconfig->titlehead?> - <?=date("Y")?></span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

  </body>

</html>

<?php
}else{
    header("location:login.php");
}
?>