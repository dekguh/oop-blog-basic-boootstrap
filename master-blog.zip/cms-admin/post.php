<?php
require_once("../conf/func.class.php");
$userClass = new funcUser();
$validator = new validator();
$articleClass = new article();
$webconfig = $userClass->webConfig();

$userClass->users = htmlentities(strip_tags(trim(@$_SESSION["ses_user"])));
$userClass->pass = htmlentities(strip_tags(trim(@$_SESSION["ses_pass"])));

if($userClass->checkSession() == 1){

  if(@$_GET["act"] == "logout"){
    session_destroy();
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=$webconfig->titleweb?> | Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="./"><?=$webconfig->titlehead?></a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="./">
            <i class="fas fa-fw fa-home"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-newspaper"></i>
            <span>Post</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./post.php?page=create">Make Post</a>
            <a class="dropdown-item" href="./post.php">List Post</a>
            <a class="dropdown-item" href="./post.php?page=category">Category</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-print"></i>
            <span>Page</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./page.php?page=create">Make Page</a>
            <a class="dropdown-item" href="./page.php">List Page</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-cog"></i>
            <span>Settings</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./setting.php?page=web">Web Settings</a>
            <a class="dropdown-item" href="./setting.php?page=seo">Seo Settings</a>
          </div>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./template.php">
            <i class="fas fa-fw fa-pencil-alt"></i>
            <span>Template</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./index.php?act=logout">
            <i class="fas fa-fw fa-long-arrow-alt-right"></i>
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">
        <?php
          if(@$_GET["page"] == "category"){

            if(@$_POST["deleteCatBtn"]){
              $catID = @$_POST["listCatID"];
              if(!empty($catID)){
                for($i=0;$i<count($catID);$i++){
                  $articleClass->catID = $catID[$i];
                  if($articleClass->validCatID() == 1){
                    $articleClass->deleteCat();
                  }
                }
              }
            }

            if(@$_GET["action"] == "delete" AND is_numeric($_GET["catid"]) AND $validator->checkSymbol($_GET["catid"]) != 1){
              $articleClass->catID = htmlentities(strip_tags(trim($_GET["catid"])));
              if($articleClass->validCatID() == 1){
                $articleClass->deleteCat();
              }
            }

            if(@$_POST["addCatBtn"]){
              $articleClass->category = htmlentities(strip_tags(strtolower($_POST["category"])));
              if(!empty($articleClass->category)){
                if($validator->checkSymbol($articleClass->category) != 1){
                  if(strlen($articleClass->category) >= 3 AND strlen($articleClass->category) <= 20){
                    $articleClass->catStatus = 1;
                    $articleClass->addCat();
                    $articleClass->msgErr = $articleClass->_alert("info","add category ".$articleClass->category." success.");
                  }else{
                    $articleClass->msgErr = $articleClass->_alert("danger","category Min 3 char and Max 20 char.");
                  }
                }else{
                  $articleClass->msgErr = $articleClass->_alert("danger","dont use symbol.");
                }
              }else{
                $articleClass->msgErr = $articleClass->_alert("danger","All form must filled.");
              }
            }
        ?>
            <div class="row">
              <div class="col-lg-4">
                <div class="card">
                  <div class="card-header">Add Category</div>
                  <div class="card-body">
                    <?=@$articleClass->msgErr?>
                    <form method="post">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="form-group">
                            <label class="form-label">Category</label>
                            <input type="text" class="form-control form-control-lg" name="category" placeholder="Category Name" />
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-lg-12">
                          <input type="submit" class="btn btn-info btn-block" value="add" name="addCatBtn" />
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>

              <?php
                $articleClass->showPage = 5;
                $articleClass->hal = (!empty($_GET["hal"]) AND @$_GET["hal"] >= 2 AND is_numeric($_GET["hal"]) AND $validator->checkSymbol($_GET["hal"]) != 1) ? $_GET["hal"] - 1 : 0 ;
                $articleClass->limitOffset = $articleClass->hal * $articleClass->showPage;

                $articleClass->category = (!empty($_GET["category"]) AND $validator->checkSymbol($_GET["category"]) != 1) ? "%".$_GET["category"]."%" : "%%" ;
                
                $articleClass->totalData = $articleClass->totalDataCat();
                $articleClass->totalHal = $articleClass->totalHal();
                $articleClass->selisih = 3;
                $articleClass->start = (@$_GET["hal"] > $articleClass->selisih AND is_numeric($_GET["hal"]) AND $validator->checkSymbol($_GET["hal"]) != 1 AND $articleClass->totalHal > $articleClass->selisih) ? $_GET["hal"] - $articleClass->selisih : 1 ;
                
                if($articleClass->totalHal <= $articleClass->selisih OR @$_GET["hal"] >= ($articleClass->totalHal - $articleClass->selisih)){
                  $articleClass->end = $articleClass->totalHal;
                }elseif(@$_GET["hal"] >= $articleClass->selisih AND @$_GET["hal"] <= ($articleClass->totalHal - $articleClass->selisih) AND is_numeric($_GET["hal"]) AND $validator->checkSymbol($_GET["hal"]) != 1){
                  $articleClass->end = $_GET["hal"] + $articleClass->selisih;
                }else{
                  $articleClass->end = $articleClass->selisih;
                }
              ?>

              <div class="col-lg-8">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="card">
                      <div class="card-body">
                        <form method="get">
                          <input type="hidden" name="page" value="category" />
                          <div class="row">
                            <div class="col-lg-9">
                              <div class="form-group">
                                <input type="text" class="form-control form-control-lg" value="<?=strip_tags(strtolower(@$_GET["category"]))?>" name="category" placeholder="Search Category" />
                              </div>
                            </div>

                            <div class="col-lg-3">
                              <div class="form-group">
                                <input type="submit" class="btn btn-info btn-block btn-lg" name="searchBtn" value="Search" />
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <br>
                <form method="post">
                <div class="row">
                  <div class="col-lg-12">
                    <table class="table table-bordered">
                      <tr>
                        <th width="4%">#</th>
                        <th>Category</th>
                        <th width="10%">Total Post</th>
                        <th width="20%">Action</th>
                      </tr>
                      <?php
                      if(!empty($articleClass->listCatData())){
                        foreach($articleClass->listCatData() as $data){
                          $articleClass->catID = $data["catid"];
                          echo "
                          <tr>
                            <td><input type='checkbox' name='listCatID[]' value='".@$data["catid"]."' /></td>
                            <td>".$data["catname"]."</td>
                            <td>".$articleClass->totalPostCat()."</td>
                            <td>
                              <a href='./post.php?page=category&action=delete&catid=".$data["catid"]."'><i class='fas fa-trash fa-lg'></i></a>
                            </td>
                          </tr>
                          ";
                        }
                      }else{
                        echo "
                        <tr>
                          <td colspan='4' align='center'>No Found</td>
                        </tr>
                        ";
                      }
                      ?>
                    </table>
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-3">
                    <input type="submit" class="btn btn-danger btn-lg" name="deleteCatBtn" value="Delete" />
                  </div>
                </div>
                </form>
                <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4">
                      <ul class="pagination justify-content-center">
                      <?php
                      if($articleClass->totalHal >= 2){
                        if(empty($_GET["hal"]) OR !is_numeric(@$_GET["hal"]) OR $validator->checkSymbol(@$_GET["hal"]) == 1 OR @$_GET["hal"] <= 1){
                          echo "<li class='page-item disabled'><a class='page-link' href=''>First</a></li>";
                        }else{
                          $articleClass->urlQuery = ["page" => "category", "category" => htmlentities(strip_tags(strtolower(@$_GET["category"]))), "hal" => 1];
                          $articleClass->urlQuery = http_build_query($articleClass->urlQuery);
                          echo "<li class='page-item'><a class='page-link' href='./post.php?".$articleClass->urlQuery."'>First</a></li>";
                        }

                        for($i = $articleClass->start;$i <= $articleClass->end;$i++){
                          if(empty($_GET["hal"]) AND $i == 1){
                            echo "<li class='page-item active'><a class='page-link' href='#'>1</a></li>";
                          }elseif(@$_GET["hal"] == $i AND is_numeric($_GET["hal"])){
                            echo "<li class='page-item active'><a class='page-link' href='#'>$i</a></li>";
                          }else{
                            $articleClass->urlQuery = ["page" => "category", "category" => htmlentities(strip_tags(strtolower(@$_GET["category"]))), "hal" => $i];
                            $articleClass->urlQuery = http_build_query($articleClass->urlQuery);
                            echo "<li class='page-item'><a class='page-link' href='./post.php?".$articleClass->urlQuery."'>$i</a></li>";
                          }
                        }

                        if($articleClass->totalHal <= 1 OR @$_GET["hal"] >= $articleClass->totalHal){
                          echo "<li class='page-item disabled'><a class='page-link' href=''>Last</a></li>";
                        }else{
                          $articleClass->urlQuery = ["page" => "category", "category" => htmlentities(strip_tags(strtolower(@$_GET["category"]))), "hal" => $articleClass->totalHal];
                          $articleClass->urlQuery = http_build_query($articleClass->urlQuery);
                          echo "<li class='page-item'><a class='page-link' href='./post.php?".$articleClass->urlQuery."'>Last</a></li>";
                        }
                      }
                      ?>
                      </ul>
                    </div>
                    <div class="col-lg-4"></div>
                </div>
              </div>
            </div>
        <?php
          }elseif(@$_GET["page"] == "create"){

            if(@$_POST["createBtn"]){
              $articleClass->postTitle = htmlentities(strip_tags($_POST["title"]));
              $articleClass->category = htmlentities(strip_tags($_POST["typecat"]));
              $articleClass->postContent = $_POST["postcontent"];
              $articleClass->tanggal = time();
              $articleClass->postStatus = 1;
              $articleClass->visitor = 0;
              $articleClass->author = $userClass->users;
              $articleClass->img = $_FILES["thumbnail"];
              $articleClass->imgName = $articleClass->img["name"];
              $articleClass->imgSize = $articleClass->img["size"]/1024; // menjadi KB
              $articleClass->imgType = $articleClass->img["type"];
              $articleClass->imgTemp = $articleClass->img["tmp_name"];
              $articleClass->imgErr = $articleClass->img["error"];

              if(!empty($articleClass->postTitle) AND !empty($articleClass->category) AND !empty($articleClass->postContent) AND !empty($articleClass->img)){
                if($articleClass->imgErr == 0){
                  if($articleClass->imgSize <= 1000 AND $articleClass->imgSize >= 50){
                    if(preg_match("/image\/(jpg|jpeg|png|PNG|JPG|JPEG)/",$articleClass->imgType) == 1){
                      if(preg_match("/php/",$articleClass->imgName) != 1){
                        if(strlen($articleClass->postTitle) >= 8 AND strlen($articleClass->postTitle) <= 60){
                          if(preg_match("/^[A-z]+[0-9]*\.(jpg|png|jpeg|PNG|JPG|JPEG){1}$/",$articleClass->imgName) == 1){
                            if(is_numeric($articleClass->category) AND $validator->checkSymbol($articleClass->category) != 1 AND $articleClass->validCatID() == 1){
                              $articleClass->addPost();
                              $articleClass->msgErr = $articleClass->_alert("success","Your article has been Publish.");
                            }else{
                              $articleClass->msgErr = $articleClass->_alert("danger","not valid value category.");
                            }
                          }else{
                            $articleClass->msgErr = $articleClass->_alert("danger","image name only type jpg, png or jpeg.");
                          }
                        }else{
                          $articleClass->msgErr = $articleClass->_alert("danger","Title min 8 char and max 60 char.");
                        }
                      }else{
                        $articleClass->msgErr = $articleClass->_alert("danger","name image dont use php.");
                      }
                    }else{
                      $articleClass->msgErr = $articleClass->_alert("danger","You only can upload image type JPG,JPEG and PNG.");
                    }
                  }else{
                    $articleClass->msgErr = $articleClass->_alert("danger","Image Size Minimum 50KB and Maximal 1MB.");
                  }
                }else{
                  $articleClass->msgErr = $articleClass->_alert("danger","Error upload.");
                }
              }else{
                $articleClass->msgErr = $articleClass->_alert("danger","All form Must filled.");
              }
            }
        ?>
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">Create Post</div>
              <div class="card-body">
                <?=$articleClass->msgErr?>
                <form method="post" enctype="multipart/form-data">
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-label">Post Title:</label>
                        <input class="form-control form-control-lg" name="title" placeholder="post title" required/>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Thumbnail</label>
                        <input type="file" name="thumbnail" class="form-control-file" />
                      </div>
                    </div>

                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Category</label>
                        <select class="form-control" name="typecat">
                          <option value="0">uknown</option>
                          <?php
                            foreach($articleClass->listCatTemp() as $data){
                              echo "<option value='".$data["catid"]."'>".$data["catname"]."</option>";
                            }
                          ?>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-group">
                        <label class="form-label">Article</label>
                        <textarea id="summernote" name="postcontent"></textarea>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-3">
                      <input type="submit" class="btn btn-success btn-block btn-lg" name="createBtn" value="Publish" />
                    </div>
                    <div class="col-lg-3">
                      <input type="submit" class="btn btn-info btn-block btn-lg" name="previewBtn" value="Preview" />
                    </div>
                    <div class="col-lg-3"></div>
                  </div>
                </form>
                  <?php
                  if(@$_POST["previewBtn"]){
                    $articleClass->postContent = $_POST["postcontent"];
                    if(!empty($articleClass->postContent) AND preg_match("/\<(\?|\?php|form|title|html|script)/",$articleClass->postContent) != 1){
                      echo "
                      <br>
                      <div class='row'>
                        <div class='col-lg-12'>
                          <div class='card'>
                            <div class='card-body'>
                              $articleClass->postContent
                            </div>
                          </div>
                        </div>
                      </div>
                      ";
                    }
                  }
                  ?>
              </div>
            </div>
          </div>
        </div>
        <?php
          }elseif(@$_GET["page"] == "edit" AND is_numeric($_GET["postid"]) AND $validator->checkSymbol($_GET["postid"]) != 1){
            $articleClass->postID = htmlentities(strip_tags(trim($_GET["postid"])));
            if($articleClass->validPostID() == 1){
              $infoPost = $articleClass->infoPost();

              if(@$_POST["editPostBtn"]){
                $articleClass->postTitle = htmlentities(strip_tags($_POST["title"]));
                $articleClass->category = htmlentities(strip_tags($_POST["typecat"]));
                $articleClass->postContent = $_POST["postcontent"];

                if(!empty($articleClass->postTitle) AND !empty($articleClass->category) AND !empty($articleClass->postContent)){
                  if(strlen($articleClass->postTitle) >= 8 AND strlen($articleClass->postTitle) <= 60){
                    if($validator->validatorTemplateSymbol($articleClass->postContent) != 1){
                      $articleClass->updatePost();
                      $articleClass->msgErr = $articleClass->_alert("success","Update Post Success.");
                      $infoPost = $articleClass->infoPost();
                    }else{
                      $articleClass->msgErr = $articleClass->_alert("danger","dont use tag php.");
                    }
                  }else{
                    $articleClass->msgErr = $articleClass->_alert("danger","title minimal 8 char and max 60 char.");
                  }
                }else{
                  $articleClass->msgErr = $articleClass->_alert("danger","All form must filled.");
                }
              }
        ?>
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-header">Edit Post</div>
              <div class="card-body">
                <?=@$articleClass->msgErr?>
                <form method="post">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Title</label>
                        <input type="text" class="form-control form-control-lg" name="title" value="<?=$infoPost["posttitle"]?>" />
                      </div>
                    </div>

                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-label">Category</label>
                        <select class="form-control" name="typecat">
                          <option value="s">s</option>
                          <?php
                          foreach($articleClass->listCatTemp() as $data){
                            $articleClass->catID = $data["catid"];
                            $articleClass->catID = $articleClass->infoCat();

                            if($infoPost["category"] == $data["catid"]){
                              echo "<option value='".$data["catid"]."' selected>".$articleClass->catID["catname"]."</option>";
                            }else{
                              echo "<option value='".$data["catid"]."'>".$articleClass->catID["catname"]."</option>";
                            }
                          }
                          ?>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-lg-12">
                      <div classs="form-group">
                        <label class="form-label">Content</label>
                        <textarea id="summernote" name="postcontent"><?=$infoPost["postcontent"]?></textarea>
                      </div>
                    </div>
                  </div>
                  <br>
                  <div class="row">
                    <div class="col-lg-3"></div>
                    <div class="col-lg-3">
                      <div class="form-group">
                        <input type="submit" class="btn btn-info btn-block btn-lg" value="edit" name="editPostBtn" />
                      </div>
                    </div>
                    <div class="col-lg-3">
                      <div class="form-group">
                        <input type="reset" class="btn btn-danger btn-block btn-lg" name="resetPostBtn" value="reset" />
                      </div>
                    </div>
                    <div class="col-lg-3"></div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <?php
            }else{
              header("location:post.php");
            }
        ?>
        
        <?php
          }else{
            if(@$_POST["deletePostBtn"]){
              $postID = $_POST["listPostID"];
              if(!empty($postID)){
                for($i=0;$i<count($postID);$i++){
                  $articleClass->postID = $postID[$i];
                  if(is_numeric($articleClass->postID) AND $validator->checkSymbol($articleClass->postID) != 1 AND $articleClass->validPostID() == 1){
                    $articleClass->deletePost();
                    header("location:post.php");
                  }
                }
              }
            }

            if(@$_GET["action"] == "delete" AND is_numeric($_GET["postid"]) AND $validator->checkSymbol($_GET["postid"]) != 1){
              $articleClass->postID = htmlentities(strip_tags(trim($_GET["postid"])));
              if($articleClass->validPostID() == 1){
                $articleClass->deletePost();
              }
            }

            $articleClass->showPage = 10;
            $articleClass->hal = (!empty($_GET["hal"]) AND is_numeric($_GET["hal"]) AND $_GET["hal"] >= 2 AND $validator->checkSymbol($_GET["hal"]) != 1) ? strip_tags($_GET["hal"]) - 1 : 0 ;
            $articleClass->limitOffset = $articleClass->hal * $articleClass->showPage;

            $articleClass->postTitle = (!empty($_GET["title"]) AND $validator->checkSymbol($_GET["title"]) != 1) ? "%".htmlentities(strip_tags($_GET["title"]))."%" : "%%" ;
            $articleClass->category = (!empty($_GET["typecat"]) AND @$_GET["typecat"] >= 0 AND is_numeric($_GET["typecat"]) AND $validator->checkSymbol($_GET["typecat"]) != 1) ? "%".htmlentities(strip_tags($_GET["typecat"]))."%" : "%%" ;
            $articleClass->postStatus = (!empty($_GET["status"]) AND @$_GET["status"] >= 1 AND @$_GET["status"] <= 2 AND is_numeric($_GET["status"]) AND $validator->checkSymbol($_GET["status"]) != 1) ? "%".$_GET["status"]."%" : "%%" ;
            
            $articleClass->selisih = 3;
            $articleClass->totalData = $articleClass->totalPostData();
            $articleClass->totalHal = ceil($articleClass->totalData/$articleClass->showPage);
            $articleClass->start = (!empty($_GET["hal"]) AND $articleClass->totalHal > $articleClass->selisih AND is_numeric(@$_GET["hal"]) AND $validator->checkSymbol(@$_GET["hal"]) != 1 AND @$_GET["hal"] > $articleClass->selisih) ? $_GET["hal"] - $articleClass->selisih : 1 ;
            
            if($articleClass->totalHal <= $articleClass->selisih OR @$_GET["hal"] >= ($articleClass->totalHal - $articleClass->selisih)){
              $articleClass->end = $articleClass->totalHal;
            }elseif(@$_GET["hal"] >= $articleClass->selisih AND is_numeric($_GET["hal"]) AND $validator->checkSymbol($_GET["hal"]) != 1){
              $articleClass->end = $_GET["hal"] + $articleClass->selisih;
            }else{
              $articleClass->end = $articleClass->selisih;
            }
        ?>
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <div class="card-body">
                <form method="get">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="form-group">
                        <input type="text" name="title" class="form-control" placeholder="Search Title" />
                      </div>
                    </div>

                    <div class="col-lg-3">
                      <div class="form-group">
                        <select class="form-control" name="typecat">
                          <option value="">All Category</option>
                        </select>
                      </div>
                    </div>

                    <div class="col-lg-3">
                      <div class="form-group">
                        <select class="form-control" name="status">
                          <option value="">All Status</option>
                        </select>
                      </div>
                    </div>

                    <div class="col-lg-3">
                      <div class="form-group">
                        <input type="submit" value="Search" class="btn btn-info btn-block" name="searchBtn" />
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <br>
        <form method="post">
        <div class="row">
          <div class="col-lg-12">
            <table class="table table-bordered">
              <tr>
                <th>#</th>
                <th>Post</th>
                <th>Category</th>
                <th>Visitor</th>
                <th>Action</th>
              </tr>
              <?php
              if(!empty($articleClass->listPost())){
                foreach($articleClass->listPost() as $data){
                  $articleClass->catID = $data["category"];
                  $articleClass->catID = $articleClass->infoCat();
                  echo "
                  <tr>
                    <td width='3%'><input type='checkbox' name='listPostID[]' value='".$data["postid"]."' /></td>
                    <td width='50%'>".htmlentities(strip_tags($data["posttitle"]))."</td>
                    <td>".$articleClass->catID["catname"]."</td>
                    <td width='8%'>".$data["visitor"]."</td>
                    <td>
                      <a href='./post.php?page=edit&postid=".$data["postid"]."'><i class='fas fa-edit fa-lg'></i></a>
                      <a href='./post.php?action=delete&postid=".$data["postid"]."'><i class='fas fa-trash fa-lg'></i></a>
                    </td>
                  </tr>
                  ";
                }
              }else{
                echo "
                <tr>
                  <td colspan='5' align='center'>No Found</td>
                </tr>
                ";
              }
              ?>
            </table>
          </div>
        </div>
        <?php
        if(!empty($articleClass->listPost())){
        ?>
        <div class="row">
          <div class="col-lg-3">
            <input type="submit" name="deletePostBtn" class="btn btn-danger btn-lg btn-block" value="delete" />
          </div>
        </div>
        <?php
        }
        ?>
        </form>

        <div class="row">
          <div class="col-lg-4"></div>
          <div class="col-lg-4">
            <ul class="pagination justify-content-center">
              <?php
              if($articleClass->totalHal >= 2){
                
                if(empty($_GET["hal"]) OR !is_numeric($_GET["hal"]) OR $validator->checkSymbol(@$_GET["hal"]) == 1 OR $_GET["hal"] <= 1){
                  echo "<li class='page-item disabled'><a class='page-link'>First</a></li>";
                }elseif(is_numeric($_GET["hal"]) AND $_GET["hal"] >= 2){
                  $articleClass->urlQuery = ["title" => @$_GET["title"], "category" => @$_GET["category"], "status" => @$_GET["status"], "hal" => 1];
                  $articleClass->urlQuery = $articleClass->buildQueryURL();
                  echo "<li class='page-item'><a class='page-link' href='./post.php?".$articleClass->urlQuery."'>First</a></li>";
                }else{
                  echo "<li class='page-item disabled'><a class='page-link'>First</a></li>";
                }

                for($i=$articleClass->start;$i<=$articleClass->end;$i++){
                  if(empty($_GET["hal"]) AND $i == 1){
                    echo "<li class='page-item active'><a class='page-link'>1</a></li>";
                  }elseif(@$_GET["hal"] == $i AND is_numeric(@$_GET["hal"]) AND $validator->checkSymbol(@$_GET["hal"]) != 1){
                    echo "<li class='page-item active'><a class='page-link'>$i</a></li>";
                  }else{
                    $articleClass->urlQuery = ["title" => @$_GET["title"], "category" => @$_GET["category"], "status" => @$_GET["status"], "hal" => $i];
                    $articleClass->urlQuery = $articleClass->buildQueryURL();
                    echo "<li class='page-item'><a class='page-link' href='./post.php?".$articleClass->urlQuery."'>$i</a></li>";
                  }
                }

                if(@$_GET["hal"] >= $articleClass->totalHal){
                  echo "<li class='page-item disabled'><a class='page-link'>Last</a></li>";
                }else{
                  $articleClass->urlQuery = ["title" => @$_GET["title"], "category" => @$_GET["category"], "status" => @$_GET["status"], "hal" => $articleClass->totalHal ];
                  $articleClass->urlQuery = $articleClass->buildQueryURL();
                  echo "<li class='page-item'><a class='page-link' href='./post.php?".$articleClass->urlQuery."'>Last</a></li>";
                }
                
              }
              ?>
            </ul>
          </div>
          <div class="col-lg-4"></div>
        </div>
        <?php
          }
        ?>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © <?=$webconfig->titlehead?> - <?=date("Y")?></span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>


    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    
    <!-- include summernote css/js -->
    <link href="dist/summernote-bs4.css" rel="stylesheet">
    <script src="dist/summernote-bs4.js"></script>

    <script>
      $(document).ready(function() {
        $('#summernote').summernote({
          height: 400
        });
      });
    </script>
  </body>

</html>

<?php
}else{
    header("location:login.php");
}
?>