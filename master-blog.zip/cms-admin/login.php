<?php
require_once("../conf/func.class.php");
$userClass = new funcUser();
$validClass = new validator();

$webConfig = $userClass->webConfig();

$userClass->users = htmlentities(strip_tags(trim(@$_SESSION["ses_user"])));
$userClass->pass = htmlentities(strip_tags(trim(@$_SESSION["ses_pass"])));

if($userClass->checkSession() == 1){
    header("location:index.php");
}else{

  if(@$_POST["login"]){
    $userClass->users = htmlentities(trim(strip_tags($_POST["username"])));
    $userClass->pass = htmlentities(trim(strip_tags($_POST["password"])));
    $validClass->recaptchasite = $webConfig->recaptchasite;
    $validClass->recaptchasecret = $webConfig->recaptchasecret;
    $validClass->_response = $_POST["g-recaptcha-response"];

    if($validClass->recaptcha() == 1){
      if(!empty($userClass->users) AND !empty($userClass->pass)){
        if($validClass->checkSymbol($userClass->users) == 0){
          if(strlen($userClass->users) >= 6 AND strlen($userClass->pass) >= 6){
            if($userClass->checkSession() == 1){
              $_SESSION["ses_user"] = $userClass->users;
              $_SESSION["ses_pass"] = $userClass->pass;
              header("location:index.php");
            }else{
              $validClass->msgErr = $validClass->_alert("danger","failed login, wrong user/pass.");
            }
          }else{
            $validClass->msgErr = $validClass->_alert("danger","minimal username & password 6 character");
          }
        }else{
          $validClass->msgErr = $validClass->_alert("danger","Exploit detect stupid, dont use symbol.");
        }
      }else{
        $validClass->msgErr = $validClass->_alert("danger","All form must filled.");
      }
    }else{
      $validClass->msgErr = $validClass->_alert("danger","Recaptcha must checked.");
    }
  }
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=$webConfig->titleweb?> - Login</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

    <script src='https://www.google.com/recaptcha/api.js'></script>

  </head>

  <body class="bg-dark">

    <div class="container">
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login</div>
        <div class="card-body">
          <?=@$validClass->msgErr?>
          <form method="post">
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="inputUsername" class="form-control" name="username" placeholder="username" required="required" autofocus="autofocus">
                <label for="inputUsername">Username</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="password" id="inputPassword" class="form-control" name="password" placeholder="Password" required="required">
                <label for="inputPassword">Password</label>
              </div>
            </div>
            <div class="form-group">
              <div class="checkbox">
                <div class="g-recaptcha" data-sitekey="<?=$webConfig->recaptchasite?>"></div>
              </div>
            </div>

            <input type="submit" name="login" class="btn btn-primary btn-block" value="login" />
          </form>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  </body>

</html>

<?php
}
?>