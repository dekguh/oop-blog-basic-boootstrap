<?php
require_once("../conf/func.class.php");
$userClass = new funcUser();
$articleClass = new article();
$webconfig = $userClass->webConfig();

$userClass->users = htmlentities(strip_tags(trim(@$_SESSION["ses_user"])));
$userClass->pass = htmlentities(strip_tags(trim(@$_SESSION["ses_pass"])));

if($userClass->checkSession() == 1){

  if(@$_GET["act"] == "logout"){
    session_destroy();
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?=$webconfig->titleweb?> | Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">

  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

      <a class="navbar-brand mr-1" href="./"><?=$webconfig->titlehead?></a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="./">
            <i class="fas fa-fw fa-home"></i>
            <span>Dashboard</span>
          </a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-newspaper"></i>
            <span>Post</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./post.php?page=create">Make Post</a>
            <a class="dropdown-item" href="./post.php">List Post</a>
            <a class="dropdown-item" href="./post.php?page=category">Category</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-print"></i>
            <span>Page</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./page.php?page=create">Make Page</a>
            <a class="dropdown-item" href="./page.php">List Page</a>
          </div>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-cog"></i>
            <span>Settings</span>
          </a>
          <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item" href="./setting.php?page=web">Web Settings</a>
            <a class="dropdown-item" href="./setting.php?page=seo">Seo Settings</a>
          </div>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./template.php">
            <i class="fas fa-fw fa-pencil-alt"></i>
            <span>Template</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="./index.php?act=logout">
            <i class="fas fa-fw fa-long-arrow-alt-right"></i>
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">

          <div class="row">
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">Latest Comment</div>
                <div class="card-body">
                  <table class="table table-bordered">
                    <tr>
                      <th>By</th> <th>Message</th> <th>Date</th>
                    </tr>
                    <?php
                    if(!empty($articleClass->latestComment(10))){
                      foreach($articleClass->latestComment(10) as $data){
                        echo "
                        <tr>
                          <td>".$data["name"]."</td>
                          <td>".$data["commentcontent"]."</td>
                          <td>".date("M d, Y h:i a",$data["tanggal"])."</td>
                        </tr>
                        ";
                      }
                    }else{
                      echo "
                      <tr>
                        <td colspan='3' align='center'>No Data</td>
                      </tr>
                      ";
                    }
                    ?>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">10 Top Post</div>
                <div class="card-body">
                  <table class="table table-bordered">
                    <tr>
                      <th>#</th>
                      <th>Post</th>
                      <th>Visitor</th>
                    </tr>
                    <?php
                    if(!empty($articleClass->listTopPost(10))){
                      $i = 1;
                      foreach($articleClass->listTopPost(10) as $data){
                        echo "
                        <tr>
                          <td>$i</td>
                          <td>".$data["posttitle"]."</td>
                          <td>".$data["visitor"]." View</td>
                        </tr>
                        ";
                        $i++;
                      }
                    }else{
                      echo "
                      <tr>
                        <td colspan='3' align='center'>No Data</td>
                      </tr>
                      ";
                    }
                    ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <br>
          <?php
          $infoUser = $userClass->infoUser();
          if(@$_POST["editBtn"]){
            $userClass->email = htmlentities(strip_tags($_POST["email"]));
            $userClass->newPass = (!empty($_POST["newpass"])) ? htmlentities(strip_tags($_POST["newpass"])) : $infoUser["password"] ;
            $userClass->oldPass = htmlentities(strip_tags($_POST["oldpass"]));
            if($userClass->oldPass == $infoUser["password"]){
              if(!empty($userClass->email) AND !empty($userClass->oldPass)){
                if(preg_match("/^[A-z]+[0-9]*[\@]{1}[A-z]+[0-9]*\.[A-z]{2,3}$/",$userClass->email) == 1){
                  if(($userClass->emailAlready() != 1 AND $userClass->email != $infoUser["email"]) OR $userClass->email == $infoUser["email"]){
                    if(strlen($userClass->newPass) >= 6 AND strlen($userClass->newPass) <= 24){
                      $userClass->userid = $infoUser["userid"];
                      $userClass->editUser();
                      $infoUser = $userClass->infoUser();
                      session_destroy();
                      header("location:login.php");
                    }else{
                      $userClass->msgErr = $userClass->_alert("danger","New Pass min 6 char and max 24 char.");
                    }
                  }else{
                    $userClass->msgErr = $userClass->_alert("danger","Email already used.");
                  }
                }else{
                  $userClass->msgErr = $userClass->_alert("danger","Email not valid.");
                }
              }else{
                $userClass->msgErr = $userClass->_alert("danger","Form email and old password must filled.");
              }
            }else{
              $userClass->msgErr = $userClass->_alert("danger","Wrong old password.");
            }
          }
          ?>
          <div class="row">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header">Update Profile</div>
                <div class="card-body">
                  <?=@$userClass->msgErr?>
                  <form method="post">
                    <div class="row">
                      <div class="col-lg-3">
                        <div class="form-group">
                          <input type="email" class="form-control" name="email" value="<?=$infoUser["email"]?>" placeholder="E-mail" />
                        </div>
                      </div>

                      <div class="col-lg-3">
                        <div class="form-group">
                          <input type="password" class="form-control" name="newpass" value="" placeholder="New Password" />
                        </div>
                      </div>

                      <div class="col-lg-3">
                        <div class="form-group">
                          <input type="password" class="form-control" name="oldpass" value="" placeholder="Old Password" />
                        </div>
                      </div>

                      <div class="col-lg-3">
                        <div class="form-group">
                          <input type="submit" class="btn btn-info btn-block" name="editBtn" value="Edit" />
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright © <?=$webconfig->titlehead?> - <?=date("Y")?></span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

  </body>

</html>

<?php
}else{
    header("location:login.php");
}
?>