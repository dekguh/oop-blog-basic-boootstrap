<?php
require_once("conf/func.class.php");

$templateClass = new template();
$articleClass = new article();
$validator = new validator();

$templateClass->templateID = 1;
$infoTemplate = $templateClass->infoTemplate();
$webConf = $templateClass->webConfig();

if($webConf->statusmt == 1){

  if(!empty($_GET["page"])){
    $articleClass->pageTitle = preg_replace("/-/"," ",$_GET["page"]);
    if(preg_match("/\'/",$articleClass->pageTitle) != 1  AND $articleClass->validPageTitle() == 1){
      $articleClass->titleWeb = $articleClass->pageTitle;
    }else{
      $articleClass->titleWeb = "404 Not found";
    }
  }else{
    $articleClass->titleWeb = "404 Not found";
  }
?>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="index, follow">
    <meta name="description" content="<?=$webConf->metadesc?>">
    <meta name="author" content="<?=$webConf->metaauthor?>">
    <meta name="keywords" content="<?=$webConf->metakeyword?>">
    <meta name="alexaVerifyID" content="<?=$webConf->alexarank?>">
    <meta name="msvalidate.01" content="<?=$webConf->metabing?>"> <!-- Bing -->
    <meta name="google-site-verification" content="<?=$webConf->googlewebmaster?>"> <!-- Google webmaster -->

    <title><?=$articleClass->titleWeb?></title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/blog-home.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="./"><?=$webConf->titlehead?></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <?=$infoTemplate["templatecontent"]?>
          </ul>
        </div>
      </div>
    </nav>
    <br>
    <!-- Page Content -->
    <div class="container">
      <form method="get" action="index.php">
        <?php
        if(!empty($_GET["category"])){
          echo "<input type='hidden' value='".$_GET["category"]."' name='category' />";
        }
        ?>
      <div class="row">
        <div class="col-lg-12">
          <div class="input-group">
            <input type="text" name="search" class="form-control form-control-lg" placeholder="Search for...">
              <span class="input-group-btn">
                <button class="btn btn-secondary btn-lg" type="submit">Go!</button>
              </span>
          </div>
        </div>
      </div>
      </form>
      <br>

      <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8">
        <?php
        if(!empty($_GET["page"])){
            $articleClass->pageTitle = strip_tags(preg_replace("/-/"," ",$_GET["page"]));
            if(preg_match("/[\']+/",$articleClass->pageTitle) != 1){
                if($articleClass->validPageTitle() == 1){
                    $infoPage = $articleClass->infoPageByTitle();
        ?>
            <!-- Title -->
            <h1 class="mt-4"><?=htmlentities(strip_tags($infoPage["pagetitle"]))?></h1>

            <hr>

            <!-- Post Content -->
            <?=$infoPage["pagecontent"]?>
            <hr>
        <?php
                }else{
                    echo "<h1 class='text-center'>404 Not Found</h1>";
                }
            }else{
                echo "<h1 class='text-center'>404 Not Found</h1>";
            }
        }
        ?>

        </div>

        <!-- Sidebar Widgets Column -->
        <div class="col-md-4">

          <!-- Categories Widget -->
          <div class="card my-4">
            <h5 class="card-header">Categories</h5>
            <div class="card-body">
              <div class="row">
                <div class="col-lg-12">
                  <ul class="list-unstyled mb-0">
                    <?php
                    foreach($articleClass->listCatTemp() as $data){
                      echo "
                      <li>
                        <a href='./index.php?category=".$data["catid"]."'>".$data["catname"]."</a>
                      </li>
                      ";
                    }
                    ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; <?=$webConf->titlehead?> <?=date("Y")?></p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
<?php
}else{
    header("location:maintance.php");
}
?>