-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Nov 25, 2018 at 07:09 AM
-- Server version: 5.7.23
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogger`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catid` int(6) NOT NULL,
  `catname` varchar(24) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `commentid` int(10) NOT NULL,
  `postid` int(10) NOT NULL,
  `name` varchar(12) COLLATE latin7_general_cs NOT NULL,
  `commentcontent` text COLLATE latin7_general_cs NOT NULL,
  `tanggal` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin7 COLLATE=latin7_general_cs;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `pageid` int(10) NOT NULL,
  `pagetitle` varchar(20) COLLATE latin7_general_cs NOT NULL,
  `pagecontent` text COLLATE latin7_general_cs NOT NULL,
  `pagestatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin7 COLLATE=latin7_general_cs;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`pageid`, `pagetitle`, `pagecontent`, `pagestatus`) VALUES
(1, 'about us', '<p>nama saya teguh</p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `postid` int(10) NOT NULL,
  `author` varchar(16) COLLATE latin7_general_cs NOT NULL,
  `posttitle` varchar(60) COLLATE latin7_general_cs NOT NULL,
  `postcontent` text COLLATE latin7_general_cs NOT NULL,
  `tanggal` int(24) NOT NULL,
  `status` int(1) NOT NULL,
  `visitor` int(8) NOT NULL,
  `thumbnail` varchar(128) COLLATE latin7_general_cs NOT NULL,
  `category` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin7 COLLATE=latin7_general_cs;

-- --------------------------------------------------------

--
-- Table structure for table `template`
--

CREATE TABLE `template` (
  `templateid` int(8) NOT NULL,
  `templatename` varchar(24) NOT NULL,
  `templatecontent` text NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `template`
--

INSERT INTO `template` (`templateid`, `templatename`, `templatecontent`, `deskripsi`) VALUES
(1, 'navbar content', '<li class=\"nav-item\">\r\n   <a class=\"nav-link\" href=\"./page.php?page=about-us\">About</a>\r\n</li>', 'tempat untuk menambahkan list pada navbar');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(8) NOT NULL,
  `typeuser` int(1) NOT NULL,
  `username` varchar(24) NOT NULL,
  `email` varchar(88) NOT NULL,
  `password` varchar(34) NOT NULL,
  `status` int(1) NOT NULL,
  `ipaddress` varchar(24) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `typeuser`, `username`, `email`, `password`, `status`, `ipaddress`) VALUES
(1, 1, 'dekguhdemo', 'dekguh@demo.com', 'dekguhdemo', 1, '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `webconfig`
--

CREATE TABLE `webconfig` (
  `statusmt` int(1) NOT NULL,
  `recaptchasecret` varchar(128) NOT NULL,
  `recaptchasite` varchar(128) NOT NULL,
  `titleweb` varchar(34) NOT NULL,
  `titlehead` varchar(12) NOT NULL,
  `metaauthor` varchar(34) NOT NULL,
  `metadesc` varchar(128) NOT NULL,
  `metakeyword` varchar(128) NOT NULL,
  `alexarank` varchar(128) NOT NULL,
  `metabing` varchar(128) NOT NULL,
  `googlewebmaster` varchar(128) NOT NULL,
  `googleanalytics` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `webconfig`
--

INSERT INTO `webconfig` (`statusmt`, `recaptchasecret`, `recaptchasite`, `titleweb`, `titlehead`, `metaauthor`, `metadesc`, `metakeyword`, `alexarank`, `metabing`, `googlewebmaster`, `googleanalytics`) VALUES
(1, '', '', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catid`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`commentid`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`pageid`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`postid`);

--
-- Indexes for table `template`
--
ALTER TABLE `template`
  ADD PRIMARY KEY (`templateid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
